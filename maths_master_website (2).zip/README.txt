Maths Master — Year 6 Maths

This is a simple website app. It works in a browser and does not need a server.

To share it with other people using a public website link:
1. Go to https://pages.github.com/ and sign in or create a GitHub account with help from a parent/guardian if needed.
2. Create a new repository named maths-master.
3. Upload index.html from this folder to the repository.
4. In the repository, open Settings → Pages.
5. Choose deployment from the main branch and save.
6. GitHub will provide a public website address you can share.

You can also use a static website host that lets you upload a folder or ZIP.

Do not share passwords or account details with anyone.
